-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: taller_motos
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `taller_motos`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `taller_motos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `taller_motos`;

--
-- Table structure for table `barcode`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `barcode` (
  `id_barcode` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  PRIMARY KEY (`id_barcode`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barcode`
--

INSERT INTO `barcode` (`id_barcode`, `nombre`, `barcode`) VALUES (7,'null','1'),(33,'Aceite','ACT001'),(36,'Llanta','LLT001');

--
-- Table structure for table `barcodem`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `barcodem` (
  `id_barcode` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  `barcode` varchar(100) NOT NULL,
  PRIMARY KEY (`id_barcode`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barcodem`
--

INSERT INTO `barcodem` (`id_barcode`, `nombre`, `barcode`) VALUES (1,'Null','1'),(8,'Pulsar 200 NS','EGQ25D'),(10,'Pulsar 200 NS','QSW34E');

--
-- Table structure for table `cilindraje`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cilindraje` (
  `id_cilindraje` int(11) NOT NULL,
  `cilindraje` varchar(50) NOT NULL,
  `precio` int(11) NOT NULL,
  PRIMARY KEY (`id_cilindraje`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cilindraje`
--

INSERT INTO `cilindraje` (`id_cilindraje`, `cilindraje`, `precio`) VALUES (1,'Ciclomotor',100900),(2,'Menos 100 c.c.',207700),(3,'De 100 a 200 c.c.',278200),(4,'Más de 200 c.c.',701300),(5,'Motocarros, tricimoto, cuatrimotos',313800);

--
-- Table structure for table `color`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `color` (
  `id_color` int(11) NOT NULL,
  `color` varchar(20) NOT NULL,
  PRIMARY KEY (`id_color`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`id_color`, `color`) VALUES (1,'Rojo eclipse');

--
-- Table structure for table `combustible`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `combustible` (
  `id_combustible` int(11) NOT NULL,
  `combustible` varchar(20) NOT NULL,
  PRIMARY KEY (`id_combustible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combustible`
--

INSERT INTO `combustible` (`id_combustible`, `combustible`) VALUES (1,'Gasolina');

--
-- Table structure for table `compras`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `compras` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `documento` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`id_compra`),
  KEY `fk` (`documento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--


--
-- Table structure for table `detalle_compra`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `detalle_compra` (
  `id_comprac` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad_producto` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  PRIMARY KEY (`id_comprac`),
  KEY `id_compra` (`id_compra`),
  KEY `fk` (`id_producto`,`id_compra`),
  CONSTRAINT `detalle_compra_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_productos`),
  CONSTRAINT `detalle_compra_ibfk_2` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_compra`
--


--
-- Table structure for table `detalle_vdocu`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `detalle_vdocu` (
  `id_detadocu` int(11) NOT NULL,
  `id_documentos` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  PRIMARY KEY (`id_detadocu`),
  KEY `id_documentos` (`id_documentos`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `detalle_vdocu_ibfk_1` FOREIGN KEY (`id_documentos`) REFERENCES `documentos` (`id_documentos`) ON UPDATE CASCADE,
  CONSTRAINT `detalle_vdocu_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `factura_venta` (`id_venta`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_vdocu`
--


--
-- Table structure for table `detalle_venta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `detalle_venta` (
  `id_detallev` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `id_venta` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  PRIMARY KEY (`id_detallev`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_venta`
--

INSERT INTO `detalle_venta` (`id_detallev`, `id_producto`, `cantidad`, `id_venta`, `subtotal`) VALUES (9,1,2,9,25000),(10,2,5,10,45000),(11,1,5,11,25000),(12,2,15,12,45000),(13,1,1,13,25000),(14,1,5,14,25000);

--
-- Table structure for table `detalle_vservi`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `detalle_vservi` (
  `id_detaservi` int(11) NOT NULL,
  `id_servicio` int(11) NOT NULL,
  `cantidad` tinyint(2) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  PRIMARY KEY (`id_detaservi`),
  KEY `id_servicio` (`id_servicio`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `detalle_vservi_ibfk_1` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicios`) ON UPDATE CASCADE,
  CONSTRAINT `detalle_vservi_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `factura_venta` (`id_venta`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_vservi`
--


--
-- Table structure for table `documentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `documentos` (
  `id_documentos` int(11) NOT NULL,
  `documentos` varchar(20) NOT NULL,
  `precio` int(11) NOT NULL,
  PRIMARY KEY (`id_documentos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentos`
--

INSERT INTO `documentos` (`id_documentos`, `documentos`, `precio`) VALUES (1,'SOAT',45000),(2,'Tecnomecanica',50000);

--
-- Table structure for table `estado`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `estado` (
  `id_estado` int(11) NOT NULL,
  `estados` varchar(25) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

INSERT INTO `estado` (`id_estado`, `estados`) VALUES (1,'Activo'),(2,'Inactivo'),(3,'Disponible'),(4,'Próximo a agotar');

--
-- Table structure for table `factura_venta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `factura_venta` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `documento` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `placa` varchar(8) NOT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `fk` (`documento`,`placa`),
  KEY `placa` (`placa`),
  CONSTRAINT `factura_venta_ibfk_2` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`),
  CONSTRAINT `factura_venta_ibfk_3` FOREIGN KEY (`placa`) REFERENCES `moto` (`placa`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_venta`
--

INSERT INTO `factura_venta` (`id_venta`, `fecha`, `documento`, `total`, `placa`) VALUES (9,'2023-05-10',1234567890,50000,'EGQ25D'),(10,'2023-05-11',1234567890,225000,'QSW34E'),(11,'2023-05-11',1234567890,125000,'EGQ25D'),(12,'2023-05-12',1234567890,675000,'QSW34E'),(13,'2023-05-12',1234567890,25000,'QSW34E'),(14,'2023-06-04',1234567890,125000,'QSW34E');

--
-- Table structure for table `linea`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `linea` (
  `id_linea` int(11) NOT NULL,
  `linea` varchar(25) NOT NULL,
  PRIMARY KEY (`id_linea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linea`
--

INSERT INTO `linea` (`id_linea`, `linea`) VALUES (1,'Pulsar 200 NS');

--
-- Table structure for table `marca`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `marca` (
  `id_marca` int(11) NOT NULL AUTO_INCREMENT,
  `marca` varchar(100) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

INSERT INTO `marca` (`id_marca`, `marca`) VALUES (1,'Bajaj');

--
-- Table structure for table `modelo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `modelo` (
  `id_modelo` int(11) NOT NULL,
  `modelo` varchar(20) NOT NULL,
  PRIMARY KEY (`id_modelo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelo`
--

INSERT INTO `modelo` (`id_modelo`, `modelo`) VALUES (1,'2014');

--
-- Table structure for table `moto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `moto` (
  `placa` varchar(8) NOT NULL,
  `id_marca` int(11) NOT NULL,
  `descripcion` varchar(90) DEFAULT NULL,
  `documento` int(11) NOT NULL,
  `km` int(11) NOT NULL,
  `id_linea` int(11) NOT NULL,
  `id_modelo` int(11) NOT NULL,
  `id_cilindraje` int(11) NOT NULL,
  `id_color` int(11) NOT NULL,
  `id_tip_servicio` int(11) NOT NULL,
  `id_clase` int(11) NOT NULL,
  `id_carroceria` int(11) NOT NULL,
  `capacidad` tinyint(2) NOT NULL,
  `id_combustible` int(11) NOT NULL,
  `numero_motor` varchar(20) NOT NULL,
  `vin` varchar(20) NOT NULL,
  `numero_chasis` varchar(20) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  PRIMARY KEY (`placa`),
  KEY `fk` (`id_marca`,`documento`),
  KEY `id_tip_servicio` (`id_tip_servicio`),
  KEY `id_modelo` (`id_modelo`),
  KEY `id_linea` (`id_linea`),
  KEY `id_combustible` (`id_combustible`),
  KEY `id_color` (`id_color`),
  KEY `id_clase` (`id_clase`),
  KEY `id_cilindraje` (`id_cilindraje`),
  KEY `id_carroceria` (`id_carroceria`),
  KEY `documento` (`documento`),
  CONSTRAINT `moto_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `marca` (`id_marca`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_10` FOREIGN KEY (`id_carroceria`) REFERENCES `tipo_carroceria` (`id_carroceria`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_11` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_3` FOREIGN KEY (`id_tip_servicio`) REFERENCES `tipo_servicio` (`id_tip_servicio`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_4` FOREIGN KEY (`id_modelo`) REFERENCES `modelo` (`id_modelo`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_5` FOREIGN KEY (`id_linea`) REFERENCES `linea` (`id_linea`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_6` FOREIGN KEY (`id_combustible`) REFERENCES `combustible` (`id_combustible`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_7` FOREIGN KEY (`id_color`) REFERENCES `color` (`id_color`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_8` FOREIGN KEY (`id_clase`) REFERENCES `tipo_vehiculo` (`id_clase`) ON UPDATE CASCADE,
  CONSTRAINT `moto_ibfk_9` FOREIGN KEY (`id_cilindraje`) REFERENCES `cilindraje` (`id_cilindraje`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moto`
--

INSERT INTO `moto` (`placa`, `id_marca`, `descripcion`, `documento`, `km`, `id_linea`, `id_modelo`, `id_cilindraje`, `id_color`, `id_tip_servicio`, `id_clase`, `id_carroceria`, `capacidad`, `id_combustible`, `numero_motor`, `vin`, `numero_chasis`, `barcode`) VALUES ('EGQ25D',1,'jauuoweu',1234567890,75,1,1,1,1,1,1,1,2,1,'23131331','1131323','12223342','EGQ25D'),('QSW34E',1,'jquhusqh',1234567890,25,1,1,1,1,1,1,1,3,1,'819993299','12132302','1029293992','QSW34E');

--
-- Table structure for table `productos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `productos` (
  `id_productos` int(11) NOT NULL,
  `nom_producto` varchar(40) NOT NULL,
  `precio` int(11) NOT NULL,
  `descripcion` varchar(70) NOT NULL,
  `cantidad_ini` int(11) NOT NULL,
  `cantidad_ant` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  PRIMARY KEY (`id_productos`),
  KEY `fk` (`id_estado`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`id_productos`, `nom_producto`, `precio`, `descripcion`, `cantidad_ini`, `cantidad_ant`, `id_estado`, `barcode`) VALUES (1,'Aceite',25000,'ueehggeu',24,18,3,'ACT001'),(2,'Llanta',45000,'ihqihii',15,16,3,'LLT001');

--
-- Table structure for table `servicio`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `servicio` (
  `id_servicios` int(11) NOT NULL,
  `servicio` varchar(20) NOT NULL,
  `precio` int(11) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  PRIMARY KEY (`id_servicios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicio`
--

INSERT INTO `servicio` (`id_servicios`, `servicio`, `precio`, `descripcion`) VALUES (1,'Cambio de aceite',30000,'ujwininwi');

--
-- Table structure for table `tipo_carroceria`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tipo_carroceria` (
  `id_carroceria` int(11) NOT NULL,
  `carroceria` varchar(20) NOT NULL,
  PRIMARY KEY (`id_carroceria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_carroceria`
--

INSERT INTO `tipo_carroceria` (`id_carroceria`, `carroceria`) VALUES (1,'Turismo');

--
-- Table structure for table `tipo_servicio`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tipo_servicio` (
  `id_tip_servicio` int(11) NOT NULL,
  `tip_servicio` varchar(20) NOT NULL,
  PRIMARY KEY (`id_tip_servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_servicio`
--

INSERT INTO `tipo_servicio` (`id_tip_servicio`, `tip_servicio`) VALUES (1,'Particular');

--
-- Table structure for table `tipo_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tipo_usuarios` (
  `id_tip_usu` int(11) NOT NULL,
  `tip_usu` varchar(30) NOT NULL,
  PRIMARY KEY (`id_tip_usu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_usuarios`
--

INSERT INTO `tipo_usuarios` (`id_tip_usu`, `tip_usu`) VALUES (1,'Administrador general'),(2,'Administrador '),(3,'Cliente');

--
-- Table structure for table `tipo_vehiculo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tipo_vehiculo` (
  `id_clase` int(11) NOT NULL,
  `tip_vehiculo` varchar(20) NOT NULL,
  PRIMARY KEY (`id_clase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_vehiculo`
--

INSERT INTO `tipo_vehiculo` (`id_clase`, `tip_vehiculo`) VALUES (1,'Motocicleta');

--
-- Table structure for table `usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `documento` int(11) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `fecha_usu` date NOT NULL,
  `usuario` varchar(15) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_tip_usu` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  PRIMARY KEY (`documento`),
  KEY `id_estado` (`id_estado`),
  KEY `id_tip_usu` (`id_tip_usu`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`) ON UPDATE CASCADE,
  CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`id_tip_usu`) REFERENCES `tipo_usuarios` (`id_tip_usu`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`documento`, `nombre_completo`, `telefono`, `email`, `fecha_usu`, `usuario`, `password`, `id_tip_usu`, `id_estado`) VALUES (1234567890,'Sebastian Vega','3173953056','juanvega2803@gmail.com','2005-03-28','admin','$2y$15$IQ8xGneqKn3YQrSo6rF3bOUAeB/YYO.fCqRaMbY5Mgw7nSYbKIeie',1,1);

--
-- Dumping routines for database 'taller_motos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-10  7:04:37
